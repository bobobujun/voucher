import { VantComponent } from '../common/component';
VantComponent({
    props: {
        dot: Boolean,
        info: null,
        customStyle: String
    }
});
