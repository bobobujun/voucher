module.exports = {
  apiHost: {
    // develop:开发版  trial:体验版  release:正式版
    develop: 'https://teste.leagpoint.com',
    // develop: 'https://creditcard.shengjingbank.com.cn',
    trial: 'https://teste.leagpoint.com',
    release: 'https://teste.leagpoint.com'
  },
}