//app.js
App({
  globalData: {
    checkVoucherInfo:{
      voucherIds:'',
      checkVoucherList:[],
      orderAmount:'',
      realAmount:''
    }
  }
})